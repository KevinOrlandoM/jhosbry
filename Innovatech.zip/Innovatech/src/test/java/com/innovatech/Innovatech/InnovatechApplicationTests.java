package com.innovatech.Innovatech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InnovatechApplicationTests {

	@Test
	void contextLoads() {
	}

}
